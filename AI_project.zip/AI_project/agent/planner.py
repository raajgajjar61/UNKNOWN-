# agents/planner.py

from agent.agentL import get_next_launch
from agent.agentW import get_weather
from agent.summary import summarize

class Planner:
    def execute(self, goal):
        print("🧠 Planner received goal:", goal)

        # Step 1: Get launch details
        launch_info = get_next_launch()
        if "error" in launch_info:
            return "❌ Failed at Launch Agent."

        # Step 2: Get weather
        city = launch_info.get("location", "Cape Canaveral")
        weather_info = get_weather(city)
        if "error" in weather_info:
            return "❌ Failed at Weather Agent."

        # Step 3: Summarize
        result = summarize(launch_info, weather_info)
        return result
