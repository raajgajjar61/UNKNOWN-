# agents/weather_agent.py

import os
from dotenv import load_dotenv
import requests

load_dotenv()

def get_weather(city):
    api_key = os.getenv("OPENWEATHER_API_KEY")
    print("🔑 API Key Loaded:", api_key)  # Debug print
    if not api_key:
        return {"error": "API key not loaded"}

    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
    print("🌍 Request URL:", url)  # Debug print

    response = requests.get(url)
    print("📡 Status Code:", response.status_code)  # Debug print
    print("📦 Response:", response.json())          # Debug print

    if response.status_code == 200:
        data = response.json()
        return {
            "weather": data["weather"][0]["description"],
            "temp": data["main"]["temp"],
            "wind": data["wind"]["speed"]
        }
    else:
        return {"error": "Failed to fetch weather"}
