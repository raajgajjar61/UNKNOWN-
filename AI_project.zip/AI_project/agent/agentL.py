# agents/launch_agent.py
import requests

def get_next_launch():
    url = "https://api.spacexdata.com/v4/launches/next"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return {
            "name": data.get("name"),
            "date": data.get("date_utc"),
            "location": "Cape Canaveral",  # You can extract from 'launchpad' with more API calls
        }
    else:
        return {"error": "Failed to fetch SpaceX launch"}
