# agents/summary_agent.py

def summarize(launch, weather):
    delay_possible = False
    reasons = []

    if "rain" in weather["weather"].lower():
        delay_possible = True
        reasons.append("rainy conditions")
    if weather["wind"] > 25:
        delay_possible = True
        reasons.append("high wind speed")
    
    if delay_possible:
        return f"🚀 Launch '{launch['name']}' on {launch['date']} from {launch['location']} might be delayed due to {', '.join(reasons)}."
    else:
        return f"🚀 Launch '{launch['name']}' on {launch['date']} from {launch['location']} is likely to proceed on schedule. Weather looks good."
