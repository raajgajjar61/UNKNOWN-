# main.py

from agent.planner import Planner

if __name__ == "__main__":
    goal = "Find the next SpaceX launch, check weather, and see if it may be delayed"
    planner = Planner()
    result = planner.execute(goal)
    print("\n✅ Final Output:\n", result)
